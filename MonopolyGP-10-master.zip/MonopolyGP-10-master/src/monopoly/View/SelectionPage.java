package monopoly.View;

import java.util.ArrayList;

public class SelectionPage {
    public SelectionPage(Character[] keyMap, String[] options) {
    }

    public int getInput() {
        return 0;
    }

    public ArrayList getOption() {
        return new ArrayList();
    }
}
