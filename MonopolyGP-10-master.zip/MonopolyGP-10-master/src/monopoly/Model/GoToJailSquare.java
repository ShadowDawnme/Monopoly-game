package monopoly.Model;

public class GoToJailSquare extends SquareBackend{
    public GoToJailSquare(int positionID) {
        super(SquareType.GOTOJAIL, positionID, "Go to Jail");
    }
}
