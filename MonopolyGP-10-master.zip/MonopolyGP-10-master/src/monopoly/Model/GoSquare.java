package monopoly.Model;

public class GoSquare extends SquareBackend{
    public GoSquare(int positionID) {
        super(SquareType.GO, positionID, "Go");
    }
}
