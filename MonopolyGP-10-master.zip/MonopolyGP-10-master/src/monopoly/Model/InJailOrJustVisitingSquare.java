package monopoly.Model;

public class InJailOrJustVisitingSquare extends SquareBackend {
    public InJailOrJustVisitingSquare(int positionID) {
        super(SquareType.INJAILORJUSTVISITING, positionID, "In jail or Visit");
    }
}
