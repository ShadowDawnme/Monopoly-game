package monopoly.Model;

public class FreeParkingSquare extends SquareBackend {
    public FreeParkingSquare(int positionID) {
        super(SquareType.FREEPARKING, positionID, "Free Parking");
    }
}
